package com.project.mydiary;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.HashSet;

public class LocalStore {
    public static final String SP_NAME = "com.project.mydiary";
    SharedPreferences userLocalDatabase;

    public LocalStore(Context context) {
        this.userLocalDatabase = context.getSharedPreferences(SP_NAME,Context.MODE_PRIVATE);
    }

    public void saveSet(HashSet<String> myset){
        SharedPreferences.Editor spEditor = userLocalDatabase.edit();
        spEditor.putStringSet("notes", myset);
        spEditor.commit();
    }
    public HashSet<String> getSet(){

        HashSet<String> temp = (HashSet<String>) userLocalDatabase.getStringSet("notes", null);
        return temp;
    }
    public void setRegistered(boolean reg){
        SharedPreferences.Editor spEditor = userLocalDatabase.edit();
        spEditor.putBoolean("registered",reg);
        spEditor.commit();


    }
    public boolean getRegistered(){
        if(userLocalDatabase.getBoolean("registered",false) == true){
            return true;
        }else
            return false;


    }

    public void storeGenPass(String genpasswd){
        SharedPreferences.Editor spEditor = userLocalDatabase.edit();
        spEditor.putString("genpasswd" ,genpasswd);
        spEditor.commit();


    }

    public String getLoggedInGenPass(){

        String password = userLocalDatabase.getString("genpasswd","");
        return password;
    }

    public void setUserLoggedIn(boolean loggedIn){
        SharedPreferences.Editor spEditor = userLocalDatabase.edit();
        spEditor.putBoolean("loggedIn",loggedIn);
        spEditor.commit();
    }

    public boolean getUserLoggedInState(){
        if(userLocalDatabase.getBoolean("loggedIn",false) == true){
            return true;
        }else
            return false;
    }
    public void clearData(){
        SharedPreferences.Editor spEditor = userLocalDatabase.edit();
        spEditor.clear();
        spEditor.commit();
    }

}
