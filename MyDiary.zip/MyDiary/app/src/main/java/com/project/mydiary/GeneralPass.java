package com.project.mydiary;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class GeneralPass extends AppCompatActivity implements View.OnClickListener {
    EditText etGP;
    Button butlogin;
    LocalStore userLocalStore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_general_pass);
        etGP = (EditText) findViewById(R.id.etGeneralPassword);
        butlogin = (Button) findViewById(R.id.bLogin);
        butlogin.setOnClickListener(this);
        userLocalStore = new LocalStore(this);

    }

    @Override
    protected void onStart() {
        super.onStart();
        if(userLocalStore.getRegistered()!=true)
            startActivity(new Intent(GeneralPass.this, Register.class));

    }

    @Override
    public void onBackPressed() {
        //super.onBackPressed();
    }

    @Override
    public void onClick(View view) {
        switch(view.getId()){
            case R.id.bLogin:
                String temp = etGP.getText().toString();
                String storedpw = userLocalStore.getLoggedInGenPass();
                if(temp.compareTo(storedpw)==0) {
                    userLocalStore.setUserLoggedIn(true);
                    startActivity(new Intent(GeneralPass.this, MainActivity.class));
                }
                else{
                    AlertDialog.Builder builder = new AlertDialog.Builder(GeneralPass.this);
                    builder.setTitle("Error.");
                    builder.setMessage("Password is not correct.");
                    builder.setNeutralButton("OK", null);
                    builder.show();
                }
                break;

        }
    }
}