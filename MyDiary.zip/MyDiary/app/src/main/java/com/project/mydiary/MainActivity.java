package com.project.mydiary;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.HashSet;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    LocalStore uls;
    Button exit;
    ListView mylistView;
    static ArrayList<String> notes = new ArrayList<>();
    static ArrayAdapter<String> itemsAdapter;

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.add_note_menu, menu);


        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId() == R.id.add_note){
            Intent intent = new Intent(this, NoteEditor.class);
            startActivity(intent);

        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        exit = (Button) findViewById(R.id.bExit);
        exit.setOnClickListener(this);

        uls = new LocalStore(this);
        mylistView = (ListView) findViewById(R.id.listview);
        HashSet<String> temp = uls.getSet();
        if(temp != null){
            notes = new ArrayList(temp);
        }

        itemsAdapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, notes);
        mylistView.setAdapter(itemsAdapter);

        mylistView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent intent = new Intent(getApplicationContext(),NoteEditor.class);
                intent.putExtra("noteid",i);
                startActivity(intent);
            }
        });


        mylistView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                int itemToDelete = i;
                new AlertDialog.Builder(MainActivity.this)
                        .setIcon(android.R.drawable.ic_dialog_alert)
                        .setTitle("Emin misiniz?")
                        .setMessage("Bu anıyı silmek üzeresiniz?")
                        .setPositiveButton("Evet", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                notes.remove(itemToDelete);
                                itemsAdapter.notifyDataSetChanged();
                                HashSet<String> set = new HashSet<>(MainActivity.notes);
                                uls.saveSet(set);
                            }
                        })
                        .setNegativeButton("Hayır",null)
                        .show();
                return true;
            }
        });

    }

    @Override
    protected void onStart() {
        super.onStart();

        if (uls.getRegistered()!=true)
            startActivity(new Intent(this,Register.class));
        else if(uls.getUserLoggedInState()!=true)
            startActivity(new Intent(this,GeneralPass.class));

    }

    @Override
    public void onBackPressed() {
        //super.onBackPressed();
    }


    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.bExit:
                uls.setUserLoggedIn(false);
                finish();
                break;
        }

    }
}